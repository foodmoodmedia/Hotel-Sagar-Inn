# Todo

- #5: Add mobile navigation menu (hamburger menu for small screens), smooth scroll animations, and final polish
