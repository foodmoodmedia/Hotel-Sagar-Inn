import Header from "@/react-app/components/Header";
import HeroSection from "@/react-app/components/HeroSection";
import AboutSection from "@/react-app/components/AboutSection";
import RoomsSection from "@/react-app/components/RoomsSection";
import AmenitiesSection from "@/react-app/components/AmenitiesSection";
import GallerySection from "@/react-app/components/GallerySection";
import ReviewsSection from "@/react-app/components/ReviewsSection";
import BookingSection from "@/react-app/components/BookingSection";
import CTASection from "@/react-app/components/CTASection";
import LocationSection from "@/react-app/components/LocationSection";
import Footer from "@/react-app/components/Footer";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <AboutSection />
        <RoomsSection />
        <AmenitiesSection />
        <GallerySection />
        <ReviewsSection />
        <BookingSection />
        <CTASection />
        <LocationSection />
      </main>
      <Footer />
    </div>
  );
}
