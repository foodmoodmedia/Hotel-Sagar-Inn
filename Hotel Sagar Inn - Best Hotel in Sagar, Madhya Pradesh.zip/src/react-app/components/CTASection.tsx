import { Phone, MessageCircle, Sparkles } from "lucide-react";

const PHONE_NUMBER = "+916264905719";
const WHATSAPP_LINK = `https://wa.me/${PHONE_NUMBER.replace("+", "")}?text=Hello,%20I%20would%20like%20to%20check%20room%20availability%20and%20best%20prices`;

export default function CTASection() {
  return (
    <section className="py-20 lg:py-24 bg-gradient-to-br from-foreground via-foreground/95 to-foreground relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gold/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />
        
        {/* Decorative Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div
            className="w-full h-full"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23D4AF37' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            }}
          />
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-gold/20 backdrop-blur-sm px-4 py-2 rounded-full mb-8">
          <Sparkles className="w-4 h-4 text-gold" />
          <span className="text-gold text-sm font-medium">Direct Booking Benefits</span>
        </div>

        {/* Headline */}
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
          Get the <span className="text-gold">Best Rates</span> When You Book Direct
        </h2>

        {/* Description */}
        <p className="text-xl text-white/70 mb-10 max-w-2xl mx-auto">
          Call now to check room availability and enjoy exclusive prices. 
          Skip the middleman and save more on your stay!
        </p>

        {/* Benefits */}
        <div className="flex flex-wrap justify-center gap-6 mb-12">
          {["Best Price Guarantee", "Free Room Upgrade*", "Flexible Cancellation", "No Booking Fees"].map(
            (benefit) => (
              <div
                key={benefit}
                className="flex items-center gap-2 text-white/80"
              >
                <div className="w-2 h-2 rounded-full bg-gold" />
                <span>{benefit}</span>
              </div>
            )
          )}
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href={`tel:${PHONE_NUMBER}`}
            className="group inline-flex items-center justify-center gap-3 px-10 py-5 rounded-full bg-white text-foreground font-bold text-lg hover:bg-gold hover:text-white transition-all shadow-2xl"
          >
            <Phone className="w-6 h-6" />
            Call Now: +91 62649 05719
          </a>
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-3 px-10 py-5 rounded-full bg-green-500 text-white font-bold text-lg hover:bg-green-600 transition-all shadow-2xl"
          >
            <MessageCircle className="w-6 h-6" />
            WhatsApp Booking
          </a>
        </div>

        {/* Small Print */}
        <p className="text-white/50 text-sm mt-8">
          *Subject to availability. Terms and conditions apply.
        </p>
      </div>
    </section>
  );
}
