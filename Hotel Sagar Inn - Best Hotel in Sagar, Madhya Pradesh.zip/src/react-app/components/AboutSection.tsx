import { MapPin, Train, TreePine, Award, Users, Clock } from "lucide-react";

const features = [
  {
    icon: Award,
    title: "3-Star Quality",
    description: "Premium hospitality standards",
  },
  {
    icon: Users,
    title: "Family Friendly",
    description: "Perfect for business & leisure",
  },
  {
    icon: Clock,
    title: "24/7 Service",
    description: "Round-the-clock assistance",
  },
];

const nearbyPlaces = [
  {
    icon: TreePine,
    name: "Chandra Park",
    distance: "5 min walk",
  },
  {
    icon: Train,
    name: "Saugor Railway Station",
    distance: "10 min drive",
  },
  {
    icon: MapPin,
    name: "Lakha Banjara Lake",
    distance: "15 min drive",
  },
];

export default function AboutSection() {
  return (
    <section id="about" className="py-20 lg:py-28 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image Grid */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="overflow-hidden rounded-2xl shadow-xl">
                  <img
                    src="https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=600&q=80"
                    alt="Hotel room"
                    className="w-full h-48 object-cover hover:scale-110 transition-transform duration-500"
                  />
                </div>
                <div className="overflow-hidden rounded-2xl shadow-xl">
                  <img
                    src="https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=600&q=80"
                    alt="Hotel lobby"
                    className="w-full h-64 object-cover hover:scale-110 transition-transform duration-500"
                  />
                </div>
              </div>
              <div className="pt-8 space-y-4">
                <div className="overflow-hidden rounded-2xl shadow-xl">
                  <img
                    src="https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=600&q=80"
                    alt="Hotel amenities"
                    className="w-full h-64 object-cover hover:scale-110 transition-transform duration-500"
                  />
                </div>
                <div className="overflow-hidden rounded-2xl shadow-xl">
                  <img
                    src="https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=600&q=80"
                    alt="Hotel exterior"
                    className="w-full h-48 object-cover hover:scale-110 transition-transform duration-500"
                  />
                </div>
              </div>
            </div>

            {/* Floating Badge */}
            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-gold to-gold-dark flex items-center justify-center">
                <span className="text-white text-2xl font-bold">15+</span>
              </div>
              <div>
                <p className="text-foreground font-semibold">Years of</p>
                <p className="text-muted-foreground text-sm">Excellence</p>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="lg:pl-8">
            <span className="inline-block text-gold font-semibold tracking-widest uppercase text-sm mb-4">
              Welcome to
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6 leading-tight">
              Hotel Sagar Inn
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-6">
              Nestled in the prestigious Civil Line area of Sagar city, Hotel Sagar Inn 
              offers a perfect blend of comfort, convenience, and warm hospitality. 
              As a trusted 3-star establishment, we cater to both business travelers 
              and families seeking a memorable stay.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Our prime location puts you within easy reach of Sagar's top attractions, 
              including the serene Lakha Banjara Lake, the vibrant Chandra Park, and 
              excellent connectivity via Saugor Railway Station.
            </p>

            {/* Features */}
            <div className="grid grid-cols-3 gap-4 mb-10">
              {features.map((feature) => (
                <div key={feature.title} className="text-center p-4 rounded-xl bg-cream hover:bg-cream-dark transition-colors">
                  <div className="w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-3">
                    <feature.icon className="w-6 h-6 text-gold" />
                  </div>
                  <h3 className="font-semibold text-foreground text-sm mb-1">{feature.title}</h3>
                  <p className="text-xs text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>

            {/* Nearby Places */}
            <div className="bg-gradient-to-r from-gold/5 to-gold/10 rounded-2xl p-6">
              <h3 className="font-semibold text-foreground mb-4">Nearby Attractions</h3>
              <div className="space-y-3">
                {nearbyPlaces.map((place) => (
                  <div key={place.name} className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                      <place.icon className="w-5 h-5 text-gold" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{place.name}</p>
                      <p className="text-sm text-muted-foreground">{place.distance}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
