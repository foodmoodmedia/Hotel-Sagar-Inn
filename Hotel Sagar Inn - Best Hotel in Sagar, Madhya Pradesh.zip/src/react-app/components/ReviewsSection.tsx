import { Star, Quote, ExternalLink } from "lucide-react";

const reviews = [
  {
    name: "Rahul Sharma",
    date: "2 weeks ago",
    rating: 5,
    text: "Excellent hotel in Sagar! The rooms are clean and spacious. Staff is very helpful and courteous. Breakfast was delicious. Highly recommended for business travelers.",
    avatar: "RS",
  },
  {
    name: "Priya Verma",
    date: "1 month ago",
    rating: 4,
    text: "Good hotel with nice ambiance. Location is perfect, close to railway station and market. The AC rooms are well maintained. Value for money.",
    avatar: "PV",
  },
  {
    name: "Amit Patel",
    date: "3 weeks ago",
    rating: 5,
    text: "Best hotel experience in Sagar city. The executive room was amazing with all modern amenities. Staff went above and beyond to make our stay comfortable.",
    avatar: "AP",
  },
  {
    name: "Sunita Joshi",
    date: "2 months ago",
    rating: 4,
    text: "Family-friendly hotel with great facilities. Kids loved the pool. Restaurant food was tasty. Only suggestion - they could add more parking space.",
    avatar: "SJ",
  },
];

export default function ReviewsSection() {
  return (
    <section id="reviews" className="py-20 lg:py-28 bg-background relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-0 left-0 w-full h-full opacity-5">
        <div className="absolute top-20 left-10">
          <Quote className="w-32 h-32 text-gold" />
        </div>
        <div className="absolute bottom-20 right-10">
          <Quote className="w-32 h-32 text-gold rotate-180" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-gold font-semibold tracking-widest uppercase text-sm mb-4">
            Testimonials
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Guest Reviews
          </h2>
          
          {/* Google Rating Badge */}
          <div className="inline-flex items-center gap-4 bg-white rounded-2xl px-6 py-4 shadow-xl shadow-black/5 border border-border">
            <div className="flex items-center gap-1">
              {[...Array(4)].map((_, i) => (
                <Star key={i} className="w-6 h-6 fill-gold text-gold" />
              ))}
              <Star className="w-6 h-6 fill-gold/50 text-gold" />
            </div>
            <div className="h-8 w-px bg-border" />
            <div className="text-left">
              <p className="text-2xl font-bold text-foreground">4.0</p>
              <p className="text-sm text-muted-foreground">390+ Reviews on Google</p>
            </div>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8 mb-12">
          {reviews.map((review, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-6 lg:p-8 shadow-lg shadow-black/5 border border-border/50 hover:shadow-xl transition-shadow"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                  {/* Avatar */}
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-gold to-gold-dark flex items-center justify-center">
                    <span className="text-white font-semibold">{review.avatar}</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">{review.name}</h4>
                    <p className="text-sm text-muted-foreground">{review.date}</p>
                  </div>
                </div>
                {/* Rating Stars */}
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < review.rating
                          ? "fill-gold text-gold"
                          : "fill-gray-200 text-gray-200"
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Review Text */}
              <div className="relative">
                <Quote className="absolute -top-2 -left-2 w-8 h-8 text-gold/20" />
                <p className="text-muted-foreground leading-relaxed pl-4">
                  {review.text}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Button */}
        <div className="text-center">
          <a
            href="https://www.google.com/maps/place/Hotel+Sagar+Inn/@23.8386,78.7378,17z"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-white border-2 border-gold text-gold font-semibold rounded-full hover:bg-gold hover:text-white transition-all shadow-lg shadow-gold/10"
          >
            View All Reviews on Google
            <ExternalLink className="w-5 h-5" />
          </a>
        </div>
      </div>
    </section>
  );
}
