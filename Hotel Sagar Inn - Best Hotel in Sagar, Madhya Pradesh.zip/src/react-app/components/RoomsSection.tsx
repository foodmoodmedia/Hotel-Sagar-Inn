import { Wifi, Wind, Tv, Coffee, Bath, Users } from "lucide-react";

const PHONE_NUMBER = "+916264905719";
const WHATSAPP_LINK = `https://wa.me/${PHONE_NUMBER.replace("+", "")}?text=Hello,%20I%20would%20like%20to%20book%20a%20room%20at%20Hotel%20Sagar%20Inn`;

interface RoomAmenity {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
}

interface Room {
  name: string;
  description: string;
  priceRange: string;
  image: string;
  amenities: RoomAmenity[];
  popular?: boolean;
}

const rooms: Room[] = [
  {
    name: "Standard Room",
    description: "Comfortable and cozy room perfect for solo travelers or couples seeking affordable comfort.",
    priceRange: "₹1,800 – ₹2,200",
    image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=800&q=80",
    amenities: [
      { icon: Wind, label: "AC" },
      { icon: Wifi, label: "WiFi" },
      { icon: Tv, label: "TV" },
      { icon: Bath, label: "Attached Bath" },
    ],
  },
  {
    name: "Deluxe Room",
    description: "Spacious room with enhanced amenities and elegant décor for a superior stay experience.",
    priceRange: "₹2,500 – ₹3,000",
    image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80",
    amenities: [
      { icon: Wind, label: "AC" },
      { icon: Wifi, label: "WiFi" },
      { icon: Tv, label: "Smart TV" },
      { icon: Coffee, label: "Tea/Coffee" },
      { icon: Bath, label: "Premium Bath" },
    ],
    popular: true,
  },
  {
    name: "Executive Room",
    description: "Premium room with luxurious amenities, work desk, and panoramic views for business travelers.",
    priceRange: "₹3,200 – ₹3,500",
    image: "https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=800&q=80",
    amenities: [
      { icon: Wind, label: "AC" },
      { icon: Wifi, label: "High-Speed WiFi" },
      { icon: Tv, label: "55\" Smart TV" },
      { icon: Coffee, label: "Mini Bar" },
      { icon: Users, label: "Lounge Access" },
    ],
  },
];

export default function RoomsSection() {
  return (
    <section id="rooms" className="py-20 lg:py-28 bg-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-gold font-semibold tracking-widest uppercase text-sm mb-4">
            Accommodations
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Our Rooms
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our selection of thoughtfully designed rooms, 
            each offering comfort and modern amenities
          </p>
        </div>

        {/* Room Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {rooms.map((room) => (
            <div
              key={room.name}
              className="group bg-white rounded-3xl overflow-hidden shadow-lg shadow-black/5 hover:shadow-2xl hover:shadow-gold/15 transition-all duration-500 hover:-translate-y-2"
            >
              {/* Image Container */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={room.image}
                  alt={room.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                {/* Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                
                {/* Popular Badge */}
                {room.popular && (
                  <div className="absolute top-4 left-4 px-4 py-1.5 bg-gold text-white text-sm font-semibold rounded-full shadow-lg">
                    Most Popular
                  </div>
                )}

                {/* Price Badge */}
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-white/95 backdrop-blur-sm rounded-xl px-4 py-3 flex items-center justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground">Starting from</p>
                      <p className="text-lg font-bold text-foreground">{room.priceRange}</p>
                    </div>
                    <span className="text-xs text-muted-foreground">/night</span>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-foreground mb-3">
                  {room.name}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-5">
                  {room.description}
                </p>

                {/* Amenities Icons */}
                <div className="flex flex-wrap gap-3 mb-6">
                  {room.amenities.map((amenity) => (
                    <div
                      key={amenity.label}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-cream rounded-full"
                    >
                      <amenity.icon className="w-4 h-4 text-gold" />
                      <span className="text-xs font-medium text-foreground">
                        {amenity.label}
                      </span>
                    </div>
                  ))}
                </div>

                {/* CTA Buttons */}
                <div className="flex gap-3">
                  <a
                    href="#booking"
                    className="flex-1 py-3 rounded-xl bg-gradient-to-r from-gold to-gold-dark text-white text-center font-semibold hover:shadow-lg hover:shadow-gold/30 transition-all"
                  >
                    Book Now
                  </a>
                  <a
                    href={`${WHATSAPP_LINK}%20-%20${encodeURIComponent(room.name)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-3 rounded-xl border-2 border-gold/30 text-gold font-semibold hover:bg-gold hover:text-white hover:border-gold transition-all"
                  >
                    Enquire
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Note */}
        <div className="mt-12 text-center">
          <p className="text-muted-foreground">
            All prices are exclusive of taxes. Rates may vary based on season and availability.
          </p>
          <p className="text-gold font-medium mt-2">
            Call us for best prices and special offers!
          </p>
        </div>
      </div>
    </section>
  );
}
