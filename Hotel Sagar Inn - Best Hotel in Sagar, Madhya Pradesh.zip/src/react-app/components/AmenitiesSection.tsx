import { Wifi, Coffee, Car, Wind, Waves, Shirt, Clock, Utensils } from "lucide-react";

const amenities = [
  {
    icon: Wifi,
    name: "Free Wi-Fi",
    description: "High-speed internet throughout",
  },
  {
    icon: Coffee,
    name: "Free Breakfast",
    description: "Complimentary morning meals",
  },
  {
    icon: Car,
    name: "Free Parking",
    description: "Secure on-site parking",
  },
  {
    icon: Wind,
    name: "Air Conditioning",
    description: "Climate-controlled rooms",
  },
  {
    icon: Waves,
    name: "Swimming Pool",
    description: "Refreshing outdoor pool",
  },
  {
    icon: Shirt,
    name: "Laundry Service",
    description: "Same-day laundry available",
  },
  {
    icon: Clock,
    name: "24/7 Front Desk",
    description: "Round-the-clock assistance",
  },
  {
    icon: Utensils,
    name: "Restaurant",
    description: "Multi-cuisine dining",
  },
];

export default function AmenitiesSection() {
  return (
    <section id="amenities" className="py-20 lg:py-28 bg-background relative overflow-hidden">
      {/* Decorative Background */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-0 w-96 h-96 bg-gold/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-gold/10 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-gold font-semibold tracking-widest uppercase text-sm mb-4">
            Facilities
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Hotel Amenities
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need for a comfortable and memorable stay
          </p>
        </div>

        {/* Amenities Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
          {amenities.map((amenity) => (
            <div
              key={amenity.name}
              className="group relative bg-white rounded-2xl p-6 lg:p-8 shadow-lg shadow-black/5 hover:shadow-xl hover:shadow-gold/10 transition-all duration-300 hover:-translate-y-1 border border-border/50"
            >
              {/* Icon Container */}
              <div className="w-14 h-14 lg:w-16 lg:h-16 rounded-2xl bg-gradient-to-br from-gold/10 to-gold/20 flex items-center justify-center mb-5 group-hover:from-gold group-hover:to-gold-dark transition-all duration-300">
                <amenity.icon className="w-7 h-7 lg:w-8 lg:h-8 text-gold group-hover:text-white transition-colors" />
              </div>

              {/* Content */}
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {amenity.name}
              </h3>
              <p className="text-sm text-muted-foreground">
                {amenity.description}
              </p>

              {/* Decorative Corner */}
              <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-gold/20 rounded-tr-lg opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          ))}
        </div>

        {/* Bottom Feature Bar */}
        <div className="mt-16 bg-gradient-to-r from-foreground via-foreground/95 to-foreground rounded-2xl p-8 lg:p-10">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
            <div className="text-center lg:text-left">
              <h3 className="text-2xl font-bold text-white mb-2">
                Need Something Special?
              </h3>
              <p className="text-white/70">
                Contact us for custom arrangements and special requests
              </p>
            </div>
            <div className="flex gap-4">
              <a
                href="tel:+916264905719"
                className="px-6 py-3 rounded-full bg-white text-foreground font-semibold hover:bg-gold hover:text-white transition-colors"
              >
                Call Us
              </a>
              <a
                href="https://wa.me/916264905719?text=Hello,%20I%20have%20a%20special%20request"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 rounded-full bg-gold text-white font-semibold hover:bg-gold-dark transition-colors"
              >
                WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
