import { useState, useEffect } from "react";
import { Phone, Menu, X } from "lucide-react";

const PHONE_NUMBER = "+916264905719";

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: "Rooms", href: "#rooms" },
    { label: "Amenities", href: "#amenities" },
    { label: "Gallery", href: "#gallery" },
    { label: "Reviews", href: "#reviews" },
    { label: "Contact", href: "#contact" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-white/95 backdrop-blur-md shadow-lg py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a href="#" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gold to-gold-dark flex items-center justify-center">
              <span className="text-white font-bold text-lg">S</span>
            </div>
            <div>
              <h1
                className={`text-xl font-semibold tracking-wide transition-colors ${
                  isScrolled ? "text-foreground" : "text-white"
                }`}
              >
                Hotel Sagar Inn
              </h1>
              <p
                className={`text-xs tracking-widest uppercase transition-colors ${
                  isScrolled ? "text-muted-foreground" : "text-white/80"
                }`}
              >
                Sagar, MP
              </p>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className={`text-sm font-medium tracking-wide transition-colors hover:text-gold ${
                  isScrolled ? "text-foreground" : "text-white"
                }`}
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* CTA Buttons */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              href={`tel:${PHONE_NUMBER}`}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${
                isScrolled
                  ? "bg-gold/10 text-gold hover:bg-gold/20"
                  : "bg-white/20 text-white hover:bg-white/30"
              }`}
            >
              <Phone className="w-4 h-4" />
              Call Now
            </a>
            <a
              href="#booking"
              className="px-5 py-2.5 rounded-full bg-gradient-to-r from-gold to-gold-dark text-white text-sm font-semibold shadow-lg shadow-gold/25 hover:shadow-gold/40 transition-all hover:scale-105"
            >
              Book Room
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`lg:hidden p-2 rounded-lg transition-colors ${
              isScrolled ? "text-foreground" : "text-white"
            }`}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 right-0 bg-white shadow-xl border-t">
          <nav className="flex flex-col p-4 gap-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="px-4 py-3 text-foreground hover:bg-cream rounded-lg transition-colors font-medium"
              >
                {link.label}
              </a>
            ))}
            <div className="flex gap-2 mt-4 pt-4 border-t">
              <a
                href={`tel:${PHONE_NUMBER}`}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-gold/10 text-gold rounded-lg font-medium"
              >
                <Phone className="w-4 h-4" />
                Call
              </a>
              <a
                href="#booking"
                onClick={() => setIsMobileMenuOpen(false)}
                className="flex-1 px-4 py-3 bg-gold text-white rounded-lg font-semibold text-center"
              >
                Book Now
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
