import { MapPin, Phone, Mail, Clock, Navigation } from "lucide-react";

const PHONE_NUMBER = "+916264905719";

const GOOGLE_MAPS_EMBED = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3667.8!2d78.7378!3d23.8386!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2sSagar%2C%20Madhya%20Pradesh%20470001!5e0!3m2!1sen!2sin!4v1600000000000";
const GOOGLE_MAPS_LINK = "https://www.google.com/maps/search/Hotel+Sagar+Inn+5+Civil+Line+Sagar+MP";

export default function LocationSection() {
  return (
    <section id="location" className="py-20 lg:py-28 bg-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-gold font-semibold tracking-widest uppercase text-sm mb-4">
            Location
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Find Us Easily
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Conveniently located near NH934, minutes from the railway station and city center
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Map */}
          <div className="lg:col-span-3 rounded-3xl overflow-hidden shadow-2xl shadow-black/10 h-[400px] lg:h-[500px]">
            <iframe
              src={GOOGLE_MAPS_EMBED}
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Hotel Sagar Inn Location"
              className="w-full h-full"
            />
          </div>

          {/* Contact Info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Address Card */}
            <div className="bg-white rounded-2xl p-6 shadow-lg shadow-black/5 border border-border/50">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-2">Address</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    5 Civil Line, Near NH934<br />
                    Sagar, Madhya Pradesh 470001<br />
                    India
                  </p>
                  <a
                    href={GOOGLE_MAPS_LINK}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-gold font-medium mt-3 hover:underline"
                  >
                    <Navigation className="w-4 h-4" />
                    Get Directions
                  </a>
                </div>
              </div>
            </div>

            {/* Phone Card */}
            <div className="bg-white rounded-2xl p-6 shadow-lg shadow-black/5 border border-border/50">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-2">Phone</h3>
                  <a
                    href={`tel:${PHONE_NUMBER}`}
                    className="text-xl font-semibold text-gold hover:underline"
                  >
                    +91 62649 05719
                  </a>
                  <p className="text-sm text-muted-foreground mt-1">
                    Call for reservations & inquiries
                  </p>
                </div>
              </div>
            </div>

            {/* Email Card */}
            <div className="bg-white rounded-2xl p-6 shadow-lg shadow-black/5 border border-border/50">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-2">Email</h3>
                  <a
                    href="mailto:info@hotelsagarinn.com"
                    className="text-gold hover:underline"
                  >
                    info@hotelsagarinn.com
                  </a>
                </div>
              </div>
            </div>

            {/* Hours Card */}
            <div className="bg-white rounded-2xl p-6 shadow-lg shadow-black/5 border border-border/50">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-2">Reception Hours</h3>
                  <p className="text-muted-foreground">
                    Open 24 hours, 7 days a week
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Check-in: 12:00 PM | Check-out: 11:00 AM
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
